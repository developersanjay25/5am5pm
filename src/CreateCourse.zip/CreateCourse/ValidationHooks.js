import { atom } from "recoil";

const Staff_Course_Type = new atom({
    key:'Staff_Course_Type',
    default:true,
})

export {Staff_Course_Type};